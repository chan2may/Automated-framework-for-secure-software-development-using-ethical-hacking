#!usr/bin/python

import os
import colorama
from colorama import Fore

print("\033[1;32m STARTING DOCKER SERVICE:")
print("service docker start")
print(Fore.WHITE+"")
os.system("service docker start")
print("")

print("\033[1;32m DISPLAY DOCKER IMAGES :")
print("docker images")
print(Fore.WHITE+"")
os.system("docker images")
print("")

print("\033[1;32m LIST THE RUNNING CONTAINERS :")
print("docker ps")
print(Fore.WHITE+"")
os.system("docker ps")
print("")

print("\033[1;32m BUILD A DOCKER IMAGE USING DOCKERFILE:")
print("docker build -t pentest .")
print(Fore.WHITE+"")
os.system("docker build -t pentest .")
print("")

print("\033[1;32m DISPLAY DOCKER IMAGES :")
print("docker images")
print(Fore.WHITE+"")
os.system("docker images")
print("")

print("\033[1;32m RUNNING ZAP SPIDER:")
print("docker run --rm -d -t owasp/zap2docker-stable zap-baseline.py -t https://www.example.com")
print(Fore.WHITE+"")
os.system("docker run --rm -d -t owasp/zap2docker-stable zap-baseline.py -t https://www.example.com")
print("")

print("\033[1;32m RUN A DOCKER CONTAINER:")
print("docker run --rm -v $(pwd):/home/chandana/Pentesting -i  pentest")
print(Fore.WHITE+"")
os.system("docker run --rm -v $(pwd):/home/chandana/Pentesting  -i  pentest")
print("")


"""

print("\033[1;32m REMOVE DOCKER IMAGE:")
print("docker rmi  pentest")
print(Fore.WHITE+"")
os.system("docker rmi pentest")
print("")


print("\033[1;32m DISPLAY DOCKER IMAGES :")
print("docker images")
print(Fore.WHITE+"")
os.system("docker images")
print("")
"""