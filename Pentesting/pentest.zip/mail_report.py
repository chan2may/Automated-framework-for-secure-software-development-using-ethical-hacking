

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header
import smtplib
import os
import json

###################################
#Fetching inputs from JSON file
###################################
with open("input.json") as jsonFile:
    jsonObject = json.load(jsonFile)
    jsonFile.close()

mail_to = jsonObject['mail_to']



####################################

def mail():
        user = 'chandana10b@gmail.com'
        app_password = 'eonakkryhdxjpiii'
        host = 'smtp.gmail.com'
        port = 465
        to = mail_to
        
        subject = 'Pentesting report'
        content_txt = 'Fuzzing report'
        attachment = 'report.txt'

        ### Define email ###    
        message = MIMEMultipart()
        # add From 
        message['From'] = Header(user)
        # add To
        message['To'] = Header(to)     
        # add Subject
        message['Subject'] = Header(subject)
        # add content text
        message.attach(MIMEText(content_txt, 'plain', 'utf-8'))
        # add attachment
        att_name = os.path.basename(attachment)
        att1 = MIMEText(open(attachment, 'rb').read(), 'base64', 'utf-8')
        att1['Content-Type'] = 'application/octet-stream'
        att1['Content-Disposition'] = 'attachment; filename=' + att_name
        message.attach(att1)
    
        ### Send email ###
        server = smtplib.SMTP_SSL(host, port) 
        server.login(user, app_password)
        server.sendmail(user, to, message.as_string()) 
        server.quit() 
        print('Sent email successfully')   