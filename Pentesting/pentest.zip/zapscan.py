#!usr/bin/python
import os
import subprocess

def zap_scan():
	print("docker run -t owasp/zap2docker-stable zap-baseline.py -t https://www.example.com")
	
	
	
