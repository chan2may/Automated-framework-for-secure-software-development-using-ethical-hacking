#!usr/bin/python

import os
import colorama
from colorama import Fore

print("\033[1;32m STARTING DOCKER SERVICE:")
print("service docker start")
print(Fore.WHITE+"")
os.system("service docker start")
print("")

print("\033[1;32m DISPLAY DOCKER IMAGES :")
print("docker images")
print(Fore.WHITE+"")
os.system("docker images")
print("")

print("\033[1;32m LIST THE RUNNING CONTAINERS :")
print("docker ps")
print(Fore.WHITE+"")
os.system("docker ps")
print("")

print("\033[1;32m RUN DVWA :")
print("docker run --rm -it -p 70:70 --name dvwa vulnerable/web-dvwa")
print(Fore.WHITE+"")
os.system("docker run --rm -it -p 70:70 --name dvwa vulnerables/web-dvwa")
print("")


print("\033[1;32m LIST THE RUNNING CONTAINERS :")
print("docker ps")
print(Fore.WHITE+"")
os.system("docker ps")
print("")